// package npc

// import chisel3._

// object Main extends App{
//     emitVerilog(new top(), Array("--target-dir", "generated"))
// }
